
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
// import java.net.InetAddress;

public class FileTransferUDPServer {
    private static final int PORT = 9876;
    private static final int PACKET_SIZE = 1024;

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("Server is running on port " + PORT);

            receiveFile(socket);

            System.out.println("File received successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void receiveFile(DatagramSocket socket) {
        try (FileOutputStream fos = new FileOutputStream("received_file.txt")) {
            byte[] buffer = new byte[PACKET_SIZE];

            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);

                // Check for the end of file transmission
                if (new String(packet.getData(), 0, packet.getLength()).equals("END")) {
                    break;
                }

                fos.write(packet.getData(), 0, packet.getLength());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}