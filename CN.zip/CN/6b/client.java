
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class FileTransferUDPClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 9876;
    private static final int PACKET_SIZE = 1024;

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress serverAddress = InetAddress.getByName(SERVER_ADDRESS);

            sendFile(socket, serverAddress);

            System.out.println("File sent successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendFile(DatagramSocket socket, InetAddress serverAddress) {
        try (FileInputStream fis = new FileInputStream("hello.txt")) {
            byte[] buffer = new byte[PACKET_SIZE];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                DatagramPacket packet = new DatagramPacket(buffer, bytesRead, serverAddress, SERVER_PORT);
                socket.send(packet);
            }

            // Send a special packet to signal the end of file transmission
            DatagramPacket endPacket = new DatagramPacket("END".getBytes(), 3, serverAddress, SERVER_PORT);
            socket.send(endPacket);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}