import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TCPEchoConcurrentClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345);
             BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader serverReader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println("Enter sentences to be echoed (type 'exit' to close):");

            String userInput;
            while (!(userInput = reader.readLine()).equalsIgnoreCase("exit")) {
                // Send user input to the server
                writer.println(userInput);

                // Receive and print the echoed text from the server
                String echoedText = serverReader.readLine();
                System.out.println("Server response: " + echoedText);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}