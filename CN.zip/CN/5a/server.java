import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class server {
    private static final int SERV_PORT = 5777;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(SERV_PORT)) {
            System.out.println("Server is listening on port " + SERV_PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connected to client");

                handleClient(clientSocket);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Received from client: " + line);

                // Reverse the line
                String reversedLine = reverseString(line);

                // Send the reversed line back to the client
                writer.println(reversedLine);
                System.out.println("Sent to client: " + reversedLine);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
                System.out.println("Client disconnected.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String reverseString(String input) {
        StringBuilder reversed = new StringBuilder(input).reverse();
        return reversed.toString();
    }
}
