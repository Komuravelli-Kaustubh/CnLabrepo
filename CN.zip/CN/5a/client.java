import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class client {
    private static final int SERV_PORT = 5777;

    public static void main(String[] args) {
        try (Socket socket = new Socket("127.0.0.1", SERV_PORT);
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader userInputReader = new BufferedReader(new InputStreamReader(System.in))) {

            String sendLine;
            String revLine;

            System.out.println("Enter the data to be sent:");

            while ((sendLine = userInputReader.readLine()) != null) {
                // Send the line to the server
                writer.println(sendLine);

                // Read the reversed line from the server
                revLine = reader.readLine();
                System.out.println("Reverse of the given sentence is: " + revLine);
                System.out.println();

                System.out.println("Enter the next data to be sent:");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}