import java.io.*;
// import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class server {
    private static final int PORT = 5000;
    private static final String FILE_PATH = "hello.txt";

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server waiting for connections on port " + PORT);
            Socket socket = serverSocket.accept();

            sendFile(socket);

            System.out.println("File sent successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendFile(Socket socket) {
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(FILE_PATH));
             OutputStream os = socket.getOutputStream()) {

            byte[] contents = new byte[10000];
            int bytesRead;
            long fileLength = new File(FILE_PATH).length();
            long current = 0;

            while ((bytesRead = bis.read(contents)) != -1) {
                os.write(contents, 0, bytesRead);
                os.flush();
                current += bytesRead;
                System.out.println("Sending file... " + (current * 100) / fileLength + "% complete!");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}