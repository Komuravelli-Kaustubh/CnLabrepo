import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class client{
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 5000;
    private static final String FILE_PATH = "received_hello.txt";

    public static void main(String[] args) {
        try (Socket socket = new Socket(InetAddress.getByName(SERVER_ADDRESS), SERVER_PORT);
             InputStream is = socket.getInputStream();
             BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(FILE_PATH))) {

            receiveFile(is, bos);

            System.out.println("File saved successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void receiveFile(InputStream is, BufferedOutputStream bos) {
        try {
            byte[] contents = new byte[10000];
            int bytesRead;

            while ((bytesRead = is.read(contents)) != -1) {
                bos.write(contents, 0, bytesRead);
            }

            bos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}