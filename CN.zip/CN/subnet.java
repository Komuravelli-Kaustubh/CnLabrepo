import java.util.*;

public class subnet{
    public static void main(String[] args){
        //Getting the IP as Integers.
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter IP : ");
        String IP = sc.next();
        String[] IPs = IP.split("\\.");
        int[] ip = new int[IPs.length];
        for(int i=0;i<IPs.length;i++){
            ip[i] = Integer.parseInt(IPs[i]);
        }
        //Number of Subnets
        System.out.print("Enter Number of Subnets : ");
        int sub = sc.nextInt();
        //Mask
        int mask = 0;
        if(ip[0]<128){
            mask = 8;
        }else if(ip[0]<192){
            mask = 16;
        }else if(ip[0]<224){
            mask = 24;
        }else{
            System.out.println("Invalid IP address.");
            return;
        }
        //Making the Subnet Ranges
        int rem  = 32 - mask;
        //Increment required for each subnet
        long incr = (long)(Math.round(Math.pow(2,rem)))/sub;

        long inc = 0;
        for(int i=0;i<sub;i++){
            System.out.print(ip[0]+".");
            System.out.print(ip[1]+ (inc/(256*256))%256 + ".");
            System.out.print(ip[2]+ (inc/256)%256 + ".");
            System.out.print(ip[3]+ inc%256);
            System.out.print("   -   ");
            inc+=incr;
            System.out.print(ip[0]+".");
            System.out.print(ip[1]+ (inc/(256*256)-1)%256 + ".");
            System.out.print(ip[2]+ (inc/256 -1)%256 + ".");
            System.out.println(ip[3]+ (inc-1)%256);
        }
    }
}