import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServer {

    public static String reverseString(String input) {
        StringBuilder reversed = new StringBuilder(input);
        return reversed.reverse().toString();
    }

    public static void main(String[] args) throws Exception {
        DatagramSocket dgs = new DatagramSocket(9999);
        byte[] receiveData = new byte[1024];
        byte[] sendData;
        DatagramPacket dgp;

        while (true) {
            // Receive data from the client
            dgp = new DatagramPacket(receiveData, receiveData.length);
            dgs.receive(dgp);
            String str = new String(dgp.getData(), 0, dgp.getLength());
            System.out.println("Data Received: " + str);

            // Reverse the string
            String reversedString = UDPServer.reverseString(str);

            // Send the reversed string back to the client
            sendData = reversedString.getBytes();
            InetAddress clientAddress = dgp.getAddress();
            int clientPort = dgp.getPort();
            dgp = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            dgs.send(dgp);
        }
    }
}